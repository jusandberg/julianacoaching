/**
 * The U Method — booking backend (Google Apps Script)
 * Deploy: Apps Script editor → Deploy → New deployment → Web app
 *         Execute as: Me     Who has access: Anyone
 * Paste the /exec URL into the booking page's ENDPOINT.
 *
 * Endpoints
 *   GET  ?action=days  &session=ID&from=ISO&to=ISO&tz=IANA  -> { days: ["2026-09-03", ...] }
 *   GET  ?action=slots &session=ID&date=YYYY-MM-DD&tz=IANA  -> { slots: [{start,end}, ...] }
 *   POST body JSON { action:"book", session, start, end, tz, name, email, phone, notes, language }
 *        -> { ok:true, meetUrl, manageUrl, eventId }
 */

var CONFIG = {
  calendarId: 'primary',              // or the coaching calendar's ID
  ownerEmail: 'hello@theumethod.ca', // organiser / notification address
  timezone: 'America/Toronto',
  slotStepMinutes: 30,                // grid the slots sit on
  bufferMinutes: 15,                  // gap kept after every session
  minNoticeHours: 24,                 // no bookings inside this window
  maxDaysAhead: 60,

  // Bookable windows, local time. Key = day of week, 0 = Sunday.
  // max caps how many slots that day can hold.
  windows: {
    2: [{ from: [17, 30], to: [19, 30] }],   // Tuesday evening
    3: [{ from: [18, 0],  to: [20, 0]  }],   // Wednesday evening
    4: [{ from: [17, 30], to: [19, 30] }],   // Thursday evening
    5: [{ from: [18, 0],  to: [20, 0]  }],   // Friday evening
    6: [{ from: [13, 0],  to: [16, 0], max: 2 }] // Saturday afternoon
  },

  // New times go live Sundays at 18:00 local, covering this many weeks out.
  release: { weekday: 0, hour: 18, weeksAhead: 2 },

  // Coaching agreement. The page requires the client to tick that they read
  // it before booking; the acknowledgement is recorded on the event and the
  // document travels with the invite.
  agreementUrl: 'https://jusandberg.github.io/julianacoaching/coaching-agreement.html',
  agreementDriveFileId: '', // optional: a Drive PDF, attached to the invite

  // Confirmation emails, on top of Google's own calendar invite.
  email: {
    toClient: true,          // branded confirmation to the client
    toOwner: true,           // "new booking" notice to Juliana
    fromName: 'Juliana · The U Method',
    replyTo: 'hello@theumethod.ca',
    siteUrl: 'https://jusandberg.github.io/julianacoaching/',
    attachIcs: true          // .ics file so any calendar app can add it
  }
};

var SESSIONS = {
  'discovery': { minutes: 30, label: 'Discovery call (30 min)' },
  'coaching':  { minutes: 60, label: 'Coaching session (60 min) — $120 CAD' },
  'eq-lite':   { minutes: 60, label: 'EQ-Lite Snapshot + Insight Session' },
  'eq-i':      { minutes: 75, label: 'EQ-i 2.0 Assessment Debrief' },
  'eq-360':    { minutes: 90, label: 'EQ-360 Leadership Debrief' }
};

// ---------------------------------------------------------------- routing

function doGet(e) {
  var action = (e.parameter.action || '').toLowerCase();
  try {
    if (action === 'days') return json({ days: availableDays(e.parameter) });
    if (action === 'slots') return json({ slots: availableSlots(e.parameter) });
    return json({ error: 'unknown action' });
  } catch (err) {
    return json({ error: String(err) });
  }
}

function doPost(e) {
  try {
    var body = JSON.parse(e.postData.contents);
    if (body.action !== 'book') return json({ ok: false, error: 'unknown action' });
    return json(createBooking(body));
  } catch (err) {
    return json({ ok: false, error: String(err) });
  }
}

function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

// ---------------------------------------------------------------- availability

function availableDays(p) {
  var session = SESSIONS[p.session] || SESSIONS.discovery;
  var from = new Date(p.from);
  var to = new Date(p.to);
  var horizon = new Date(Date.now() + CONFIG.maxDaysAhead * 864e5);
  if (to > horizon) to = horizon;

  var out = [];
  var cursor = new Date(from.getFullYear(), from.getMonth(), from.getDate());
  while (cursor <= to) {
    var key = dateKey(cursor);
    if (slotsForDay(key, session).length > 0) out.push(key);
    cursor = new Date(cursor.getTime() + 864e5);
  }
  return out;
}

/**
 * Last release that has already happened, plus the published weeks.
 * Nothing beyond this is offered, so the page never shows times Juliana
 * has not released yet.
 */
function releaseHorizon() {
  var now = new Date();
  var s = new Date(now.getFullYear(), now.getMonth(), now.getDate(), CONFIG.release.hour, 0, 0);
  s.setDate(s.getDate() - ((s.getDay() - CONFIG.release.weekday + 7) % 7));
  if (s.getTime() > now.getTime()) s.setDate(s.getDate() - 7);
  return s.getTime() + CONFIG.release.weeksAhead * 7 * 864e5;
}

function availableSlots(p) {
  var session = SESSIONS[p.session] || SESSIONS.discovery;
  return slotsForDay(p.date, session);
}

function slotsForDay(dateKey, session) {
  var parts = dateKey.split('-').map(Number);
  var day = new Date(parts[0], parts[1] - 1, parts[2]);
  var windows = CONFIG.windows[day.getDay()];
  if (!windows || !windows.length) return [];

  var notBefore = Date.now() + CONFIG.minNoticeHours * 3600e3;
  var horizon = releaseHorizon();

  var scanStart = new Date(parts[0], parts[1] - 1, parts[2], 0, 0, 0);
  var scanEnd = new Date(parts[0], parts[1] - 1, parts[2], 23, 59, 59);

  var cal = CalendarApp.getCalendarById(CONFIG.calendarId === 'primary'
    ? Session.getEffectiveUser().getEmail() : CONFIG.calendarId);
  var busy = cal.getEvents(scanStart, scanEnd).filter(function (ev) {
    return ev.getMyStatus() !== CalendarApp.GuestStatus.NO;
  }).map(function (ev) {
    return {
      start: ev.getStartTime().getTime() - CONFIG.bufferMinutes * 60e3,
      end: ev.getEndTime().getTime() + CONFIG.bufferMinutes * 60e3
    };
  });

  var step = CONFIG.slotStepMinutes * 60e3;
  var length = session.minutes * 60e3;
  var out = [];

  windows.forEach(function (w) {
    var from = new Date(parts[0], parts[1] - 1, parts[2], w.from[0], w.from[1]).getTime();
    var to = new Date(parts[0], parts[1] - 1, parts[2], w.to[0], w.to[1]).getTime();
    var found = [];
    for (var t = from; t + length <= to; t += step) {
      if (t < notBefore || t > horizon) continue;
      var clash = busy.some(function (b) { return t < b.end && (t + length) > b.start; });
      if (clash) continue;
      found.push({
        start: new Date(t).toISOString(),
        end: new Date(t + length).toISOString()
      });
    }
    if (w.max) found = found.slice(0, w.max);
    out = out.concat(found);
  });

  return out;
}

function dateKey(d) {
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
}

function pad(n) { return n < 10 ? '0' + n : String(n); }

// ---------------------------------------------------------------- booking

function createBooking(b) {
  var session = SESSIONS[b.session] || SESSIONS.discovery;
  var start = new Date(b.start);
  var end = new Date(b.end);

  // Re-check the slot server side — the page may be holding a stale grid.
  var stillOpen = slotsForDay(dateKey(start), session).some(function (s) {
    return Math.abs(new Date(s.start).getTime() - start.getTime()) < 60e3;
  });
  if (!stillOpen) return { ok: false, error: 'slot_taken' };

  // The agreement acknowledgement is required — never create the event without it.
  if (b.agreementAccepted !== true) return { ok: false, error: 'agreement_required' };

  var calId = CONFIG.calendarId === 'primary'
    ? Session.getEffectiveUser().getEmail() : CONFIG.calendarId;

  var description = [
    session.label,
    'Name: ' + b.name,
    'Email: ' + b.email,
    b.phone ? 'Phone: ' + b.phone : '',
    'Language: ' + b.language,
    b.notes ? '\nWhat they would like to bring:\n' + b.notes : '',
    '\nCoaching Agreement: read and accepted at ' +
      Utilities.formatDate(new Date(b.agreementAcceptedAt || new Date()), CONFIG.timezone, 'yyyy-MM-dd HH:mm z'),
    CONFIG.agreementUrl,
    '\nBooked from theumethod booking page.'
  ].filter(String).join('\n');

  var attachments = [];
  if (CONFIG.agreementDriveFileId) {
    var file = DriveApp.getFileById(CONFIG.agreementDriveFileId);
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    attachments.push({
      fileUrl: file.getUrl(),
      title: 'Coaching Agreement',
      mimeType: file.getMimeType()
    });
  }

  // Advanced Calendar Service (enable "Calendar API" under Services) —
  // required for an auto-created Google Meet link.
  var event = Calendar.Events.insert({
    summary: session.label + ' — ' + b.name,
    description: description,
    start: { dateTime: start.toISOString(), timeZone: b.tz || CONFIG.timezone },
    end: { dateTime: end.toISOString(), timeZone: b.tz || CONFIG.timezone },
    attendees: [{ email: b.email, displayName: b.name }, { email: CONFIG.ownerEmail, organizer: true }],
    attachments: attachments,
    guestsCanModify: false,
    reminders: { useDefault: false, overrides: [
      { method: 'email', minutes: 24 * 60 },
      { method: 'popup', minutes: 30 }
    ] },
    conferenceData: {
      createRequest: {
        requestId: Utilities.getUuid(),
        conferenceSolutionKey: { type: 'hangoutsMeet' }
      }
    }
  }, calId, { conferenceDataVersion: 1, supportsAttachments: true, sendUpdates: 'all' });

  var meetUrl = event.hangoutLink ||
    (event.conferenceData && event.conferenceData.entryPoints &&
     event.conferenceData.entryPoints[0] && event.conferenceData.entryPoints[0].uri) || '';

  sendConfirmationEmails(b, session, start, end, meetUrl, event.htmlLink || '');

  return {
    ok: true,
    eventId: event.id,
    meetUrl: meetUrl,
    manageUrl: event.htmlLink || '',
    agreementAttached: attachments.length > 0
  };
}

// ---------------------------------------------------------------- emails

/**
 * Two emails per booking, in the client's chosen language:
 *  - to the client: what they booked, the Meet link, the agreement, how to change it
 *  - to Juliana: a plain notice with everything the client wrote
 * Google still sends its own calendar invite; these are the branded ones.
 */
function sendConfirmationEmails(b, session, start, end, meetUrl, manageUrl) {
  var pt = /portugu/i.test(b.language || '');
  var when = Utilities.formatDate(start, b.tz || CONFIG.timezone,
    pt ? "EEEE, d 'de' MMMM 'de' yyyy '\u00e0s' HH:mm" : "EEEE, MMMM d, yyyy 'at' h:mm a");
  var tzName = (b.tz || CONFIG.timezone).replace(/_/g, ' ');

  var attachments = [];
  if (CONFIG.email.attachIcs) {
    attachments.push(Utilities.newBlob(
      buildIcs(session, b, start, end, meetUrl),
      'text/calendar', 'session.ics'
    ));
  }

  if (CONFIG.email.toClient) {
    var t = pt ? {
      subject: 'Confirmado: ' + session.label + ' \u00b7 ' + when,
      hi: 'Ol\u00e1 ' + firstName(b.name) + ',',
      lead: 'Sua sess\u00e3o est\u00e1 confirmada. Aqui est\u00e3o os detalhes \u2014 tamb\u00e9m enviei o convite para a sua agenda.',
      lblSession: 'Sess\u00e3o', lblWhen: 'Quando', lblMeet: 'Link do encontro',
      lblAgreement: 'Contrato de Coaching', agreementRead: 'Lido e aceito no agendamento',
      changeLead: 'Precisa reagendar ou cancelar?',
      changeLink: 'Use este link',
      closing: 'At\u00e9 breve,',
      sign: 'Juliana',
      prep: 'N\u00e3o precisa preparar nada. Venha exatamente como voc\u00ea est\u00e1.'
    } : {
      subject: 'Confirmed: ' + session.label + ' \u00b7 ' + when,
      hi: 'Hi ' + firstName(b.name) + ',',
      lead: 'Your session is confirmed. Here are the details \u2014 the calendar invite is on its way too.',
      lblSession: 'Session', lblWhen: 'When', lblMeet: 'Meeting link',
      lblAgreement: 'Coaching Agreement', agreementRead: 'Read and accepted at booking',
      changeLead: 'Need to reschedule or cancel?',
      changeLink: 'Use this link',
      closing: 'See you soon,',
      sign: 'Juliana',
      prep: 'Nothing to prepare. Come exactly as you are.'
    };

    var rows = [
      [t.lblSession, esc(session.label)],
      [t.lblWhen, esc(when) + ' &middot; ' + esc(tzName)],
      [t.lblMeet, meetUrl ? '<a href="' + meetUrl + '" style="color:#385768">' + esc(meetUrl) + '</a>' : '&mdash;'],
      [t.lblAgreement, esc(t.agreementRead) + ' &middot; <a href="' + CONFIG.agreementUrl + '" style="color:#385768">' + esc(t.lblAgreement) + '</a>']
    ].map(function (r) {
      return '<tr>' +
        '<td style="padding:12px 0;border-bottom:1px solid #d9dee4;color:#7d6231;font:700 11px/1.4 Arial,sans-serif;letter-spacing:.12em;text-transform:uppercase;width:150px;vertical-align:top">' + r[0] + '</td>' +
        '<td style="padding:12px 0;border-bottom:1px solid #d9dee4;color:#101419;font:400 15px/1.5 Arial,sans-serif">' + r[1] + '</td>' +
      '</tr>';
    }).join('');

    var html =
      '<div style="margin:0;padding:32px 16px;background:#f8f9fa">' +
        '<div style="max-width:560px;margin:0 auto;padding:32px;background:#fff;border:1px solid #d9dee4;border-top:3px solid #d9b75e;border-radius:8px">' +
        '<p style="margin:0 0 6px;color:#7d6231;font:700 11px/1.4 Arial,sans-serif;letter-spacing:.12em;text-transform:uppercase">The U Method</p>' +
        '<h1 style="margin:0 0 16px;color:#101419;font:400 26px/1.2 Georgia,serif">' + esc(t.hi) + '</h1>' +
        '<p style="margin:0 0 24px;color:#66707a;font:400 15px/1.6 Arial,sans-serif">' + esc(t.lead) + '</p>' +
        '<table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse;border-top:1px solid #d9dee4">' + rows + '</table>' +
        '<p style="margin:24px 0 0;color:#66707a;font:400 14px/1.6 Arial,sans-serif">' + esc(t.prep) + '</p>' +
        '<p style="margin:16px 0 0;padding-top:18px;border-top:1px solid #d9dee4;color:#66707a;font:400 14px/1.6 Arial,sans-serif">' +
          esc(t.changeLead) + ' <a href="' + (manageUrl || CONFIG.email.siteUrl) + '" style="color:#385768;font-weight:700">' + esc(t.changeLink) + '</a>.</p>' +
        '<p style="margin:24px 0 0;color:#101419;font:400 15px/1.6 Arial,sans-serif">' + esc(t.closing) + '<br>' +
          '<span style="font:italic 19px/1.4 Georgia,serif;color:#7d6231">' + esc(t.sign) + '</span></p>' +
      '</div></div>';

    MailApp.sendEmail({
      to: b.email,
      subject: t.subject,
      htmlBody: html,
      name: CONFIG.email.fromName,
      replyTo: CONFIG.email.replyTo,
      attachments: attachments
    });
  }

  if (CONFIG.email.toOwner) {
    var body = [
      session.label,
      when + ' (' + tzName + ')',
      '',
      'Name: ' + b.name,
      'Email: ' + b.email,
      b.phone ? 'Phone: ' + b.phone : '',
      'Language: ' + b.language,
      '',
      b.notes ? 'What they would like to bring:\n' + b.notes : 'No notes added.',
      '',
      'Coaching Agreement accepted: ' +
        Utilities.formatDate(new Date(b.agreementAcceptedAt || new Date()), CONFIG.timezone, 'yyyy-MM-dd HH:mm z'),
      meetUrl ? 'Meet: ' + meetUrl : '',
      manageUrl ? 'Event: ' + manageUrl : ''
    ].filter(String).join('\n');

    MailApp.sendEmail({
      to: CONFIG.ownerEmail,
      subject: 'New booking · ' + b.name + ' · ' + when,
      body: body,
      name: 'The U Method booking page',
      replyTo: b.email
    });
  }
}

function buildIcs(session, b, start, end, meetUrl) {
  var z = function (d) { return Utilities.formatDate(d, 'UTC', "yyyyMMdd'T'HHmmss'Z'"); };
  return [
    'BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//The U Method//Booking//EN', 'BEGIN:VEVENT',
    'UID:' + Utilities.getUuid() + '@theumethod',
    'DTSTAMP:' + z(new Date()),
    'DTSTART:' + z(start),
    'DTEND:' + z(end),
    'SUMMARY:' + session.label,
    'DESCRIPTION:' + (meetUrl ? 'Google Meet: ' + meetUrl : ''),
    meetUrl ? 'LOCATION:' + meetUrl : '',
    'END:VEVENT', 'END:VCALENDAR'
  ].filter(String).join('\r\n');
}

function firstName(name) {
  return String(name || '').trim().split(/\s+/)[0] || '';
}

function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
