# Booking page — ready to go

Two files, two places.

## 1. GitHub (`jusandberg/julianacoaching`)

- Upload `booking.html` to the repo root, replacing the existing one.
- Delete the stray `booking (4).html`.
- Nothing else: the page uses the repo's own `styles.css`, `script.js` and
  `logo.svg`.

## 2. Apps Script (script.google.com)

- New project → paste `apps-script/Code.gs`, replacing the default file.
- Fill in the three placeholders at the top of `CONFIG`:
  - `calendarId` — leave as `'primary'` or the coaching calendar's ID
  - `ownerEmail` — Juliana's real address
  - `email.replyTo` — same address
- **Services → + Add a service → Calendar API** (needed for the Meet link).
- Deploy → New deployment → Web app · Execute as **Me** · Access **Anyone**.
- Copy the `/exec` URL.

## 3. The one line that connects them

In `booking.html`, around line 297:

```js
var ENDPOINT = ''; // paste the Apps Script /exec URL here
```

Paste the `/exec` URL between the quotes and re-upload. Until then the page
shows sample times and sends nothing.

---

# Reference


## Scheduling rules (already set in `CONFIG`)

| Rule | Value |
| --- | --- |
| Timezone | America/Toronto |
| Minimum notice | 24 hours |
| Tuesday | 5:30–7:30 PM |
| Wednesday | 6:00–8:00 PM |
| Thursday | 5:30–7:30 PM |
| Friday | 6:00–8:00 PM |
| Saturday | 1:00–4:00 PM, max 2 slots |
| Release | Sundays 6:00 PM, two weeks published at a time |
| Buffer | 15 min after every session |

Discovery call 30 min (free) · coaching session 60 min ($120 CAD) ·
EQ debriefs 60 / 75 / 90 min. The EQ-360 leadership debrief is not directly
bookable — it points the client to the discovery call first.

## What the endpoint returns

| Call | Response |
| --- | --- |
| `GET ?action=days&session=ID&from=ISO&to=ISO&tz=IANA` | `{ "days": ["2026-09-03", …] }` — days with at least one opening |
| `GET ?action=slots&session=ID&date=YYYY-MM-DD&tz=IANA` | `{ "slots": [{ "start": ISO, "end": ISO }, …] }` |
| `POST { action:"book", session, start, end, tz, name, email, phone, notes, language, agreementAccepted, agreementAcceptedAt }` | `{ "ok": true, "meetUrl": "…", "manageUrl": "…", "eventId": "…" }` |

## Confirmation emails

Every booking sends two emails, on top of Google's own calendar invite:

- **To the client** — a branded HTML confirmation in their chosen language
  (English or Português): session, date and time with timezone, the Meet
  link, the agreement acknowledgement with a link to it, and a
  reschedule/cancel link. A `session.ics` file is attached so any calendar
  app can add it.
- **To Juliana** — a plain notice with the name, email, phone, language,
  what they wrote in "what would you like to bring", the agreement
  timestamp, and links to the Meet and the event. Reply-to is set to the
  client, so replying goes straight to them.

Both are controlled in `CONFIG.email` — `toClient`, `toOwner`, `fromName`,
`replyTo`, `attachIcs`. Set either flag to `false` to turn that email off.

Note on volume: a consumer Gmail account can send about 100 emails a day
through Apps Script, a Workspace account about 1,500. Two per booking, so
not a concern here.

## The coaching agreement

The details form has a required checkbox linking to
`coaching-agreement.html`. Booking is blocked until it is ticked, and the
backend refuses any request without `agreementAccepted: true` — so no event
can exist without an acknowledgement.

What lands on the event: the client's name, email, phone, language, what
they want to bring, and a line recording the exact timestamp they accepted
the agreement, with the link.

To attach the document itself to the invite, put a PDF of the agreement in
Drive and set `agreementDriveFileId` in `CONFIG`. The script shares it
view-only by link and attaches it, so the client sees it in the invite
alongside the Meet link. Left blank, the invite carries the link only.

The script re-checks the slot before creating the event, so two people
clicking the same time cannot double-book — the loser gets a "pick another
time" message.

## Notes

- Free/busy comes from the real calendar, so anything Juliana blocks out
  disappears from the page automatically.
- `sendUpdates: 'all'` makes Google send the invite and reminder emails —
  no separate mail setup.
- `manageUrl` is the event's own Google link, which is where reschedule and
  cancel happen. If you would rather have a branded reschedule page, that is
  a second endpoint and a small extra screen.
- Payment stays out of the flow: paid sessions are invoiced after booking.
